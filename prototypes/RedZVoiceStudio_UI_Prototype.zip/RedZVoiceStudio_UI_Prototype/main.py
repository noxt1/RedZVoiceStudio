import tkinter as tk
from tkinter import ttk
from datetime import datetime

BG = "#080D13"
PANEL = "#111A24"
PANEL_2 = "#172330"
PANEL_3 = "#1C2A38"
BORDER = "#2A3A49"
TEXT = "#E8EEF3"
MUTED = "#91A0AE"
GOLD = "#C9A46A"
GOLD_HI = "#E2C18A"
GREEN = "#65D6A5"
RED = "#E47B78"
BLUE = "#83BFEA"

class RedZPrototype:
    def __init__(self, root):
        self.root = root
        self.root.title("RedZ Voice Studio — UI Prototype")
        self.root.geometry("1440x900")
        self.root.minsize(1120, 720)
        self.root.configure(bg=BG)
        self.engine_state = "STOPPED"
        self.active_page = "Главная"
        self.nav = {}
        self._style()
        self._build_shell()
        self.show_page("Главная")
        self.root.after(150, self._clock)

    def _style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure("TCombobox", fieldbackground=PANEL_2, background=PANEL_2,
                    foreground=TEXT, arrowcolor=GOLD, bordercolor=BORDER,
                    lightcolor=BORDER, darkcolor=BORDER, padding=7)
        s.map("TCombobox", fieldbackground=[("readonly", PANEL_2)],
              foreground=[("readonly", TEXT)])
        s.configure("Horizontal.TScale", background=PANEL, troughcolor=PANEL_3,
                    sliderthickness=14)

    def _build_shell(self):
        self.shell = tk.Frame(self.root, bg=BG)
        self.shell.pack(fill="both", expand=True, padx=24, pady=20)

        header = tk.Frame(self.shell, bg=BG)
        header.pack(fill="x", pady=(0, 18))
        brand = tk.Frame(header, bg=BG)
        brand.pack(side="left")
        mark = tk.Canvas(brand, width=42, height=42, bg=BG, highlightthickness=0)
        mark.pack(side="left", padx=(0, 12))
        mark.create_oval(3, 3, 39, 39, outline=GOLD, width=2)
        mark.create_text(21, 21, text="RZ", fill=GOLD_HI, font=("Segoe UI", 11, "bold"))
        titlebox = tk.Frame(brand, bg=BG)
        titlebox.pack(side="left")
        tk.Label(titlebox, text="REDZ VOICE STUDIO", bg=BG, fg=TEXT,
                 font=("Segoe UI Semibold", 15)).pack(anchor="w")
        tk.Label(titlebox, text="REAL-TIME VOICE TRANSLATION", bg=BG, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", pady=(2, 0))

        self.clock_label = tk.Label(header, text="", bg=BG, fg=MUTED,
                                    font=("Segoe UI", 10))
        self.clock_label.pack(side="right", padx=8)
        self.engine_badge = tk.Label(header, text="● ENGINE STOPPED", bg=PANEL,
                                     fg=GOLD, font=("Segoe UI", 9, "bold"),
                                     padx=14, pady=9)
        self.engine_badge.pack(side="right", padx=(0, 12))

        body = tk.Frame(self.shell, bg=BG)
        body.pack(fill="both", expand=True)
        self.sidebar = tk.Frame(body, bg=PANEL, width=220,
                                highlightbackground=BORDER, highlightthickness=1)
        self.sidebar.pack(side="left", fill="y", padx=(0, 18))
        self.sidebar.pack_propagate(False)

        tk.Label(self.sidebar, text="WORKSPACE", bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=20, pady=(24, 12))
        for name, glyph in [("Главная", "⌂"), ("Голоса", "◉"),
                            ("Настройки", "⚙"), ("История", "≡")]:
            b = tk.Button(self.sidebar, text=f"  {glyph}    {name}", anchor="w",
                          command=lambda n=name: self.show_page(n),
                          bg=PANEL, fg=MUTED, activebackground=PANEL_3,
                          activeforeground=TEXT, relief="flat", bd=0,
                          font=("Segoe UI", 11), padx=18, pady=13, cursor="hand2")
            b.pack(fill="x", padx=10, pady=2)
            self.nav[name] = b

        tk.Frame(self.sidebar, bg=BORDER, height=1).pack(fill="x", padx=18, pady=20)
        tk.Label(self.sidebar, text="ENGINE STATUS", bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=20)
        self.sidebar_engine = tk.Label(self.sidebar, text="Остановлен",
                 bg=PANEL, fg=GOLD, font=("Segoe UI", 10))
        self.sidebar_engine.pack(anchor="w", padx=20, pady=(8, 3))
        tk.Label(self.sidebar, text="UI prototype · backend не подключён",
                 bg=PANEL, fg="#687887", font=("Segoe UI", 8),
                 wraplength=175, justify="left").pack(anchor="w", padx=20, pady=(8, 0))

        self.content = tk.Frame(body, bg=BG)
        self.content.pack(side="left", fill="both", expand=True)

        footer = tk.Frame(self.shell, bg=BG)
        footer.pack(fill="x", pady=(12, 0))
        tk.Label(footer, text="REDZ VOICE STUDIO  /  DESIGN PROTOTYPE",
                 bg=BG, fg="#657583", font=("Segoe UI", 8, "bold")).pack(side="left")
        tk.Label(footer, text="Legacy engine untouched", bg=BG, fg="#657583",
                 font=("Segoe UI", 8)).pack(side="right")

    def _clock(self):
        self.clock_label.config(text=datetime.now().strftime("%d %b %Y   %H:%M"))
        self.root.after(1000, self._clock)

    def card(self, parent, title, subtitle=None, accent=GOLD):
        outer = tk.Frame(parent, bg=PANEL, highlightbackground=BORDER,
                         highlightthickness=1)
        top = tk.Frame(outer, bg=PANEL)
        top.pack(fill="x", padx=20, pady=(17, 8))
        tk.Frame(top, bg=accent, width=3, height=28).pack(side="left", padx=(0, 11))
        labels = tk.Frame(top, bg=PANEL)
        labels.pack(side="left", fill="x", expand=True)
        tk.Label(labels, text=title.upper(), bg=PANEL, fg=TEXT,
                 font=("Segoe UI Semibold", 10)).pack(anchor="w")
        if subtitle:
            tk.Label(labels, text=subtitle, bg=PANEL, fg=MUTED,
                     font=("Segoe UI", 9)).pack(anchor="w", pady=(3, 0))
        return outer

    def button(self, parent, text, command=None, primary=False, width=None):
        return tk.Button(parent, text=text, command=command,
            bg=GOLD if primary else PANEL_3,
            fg="#101820" if primary else TEXT,
            activebackground=GOLD_HI if primary else "#26394A",
            activeforeground="#101820" if primary else TEXT,
            relief="flat", bd=0, padx=16, pady=10,
            font=("Segoe UI Semibold", 9), cursor="hand2", width=width)

    def section_heading(self, title, desc):
        tk.Label(self.content, text=title, bg=BG, fg=TEXT,
                 font=("Segoe UI Semibold", 23)).pack(anchor="w")
        tk.Label(self.content, text=desc, bg=BG, fg=MUTED,
                 font=("Segoe UI", 10)).pack(anchor="w", pady=(5, 18))

    def show_page(self, page):
        self.active_page = page
        for name, b in self.nav.items():
            b.configure(bg=PANEL_3 if name == page else PANEL,
                        fg=GOLD_HI if name == page else MUTED)
        for w in self.content.winfo_children():
            w.destroy()
        {"Главная": self._home, "Голоса": self._voices,
         "Настройки": self._settings, "История": self._history}[page]()

    def _home(self):
        self.section_heading("Главная", "Управление переводом и состоянием голосового движка")
        engine = self.card(self.content, "Движок перевода",
                           "Модели загружаются только после явной команды пользователя")
        engine.pack(fill="x", pady=(0, 14))
        row = tk.Frame(engine, bg=PANEL)
        row.pack(fill="x", padx=20, pady=(6, 18))
        self.state_text = tk.Label(row, text="STOPPED  ·  Движок не запущен",
                                   bg=PANEL, fg=GOLD, font=("Segoe UI Semibold", 11))
        self.state_text.pack(side="left")
        self.start_btn = self.button(row, "Запустить модель", self._demo_start, True)
        self.start_btn.pack(side="right", padx=(8, 0))
        self.stop_btn = self.button(row, "Остановить", self._demo_stop)
        self.stop_btn.pack(side="right")

        grid = tk.Frame(self.content, bg=BG)
        grid.pack(fill="x", pady=(0, 14))
        grid.columnconfigure((0, 1), weight=1, uniform="direction")
        self._direction_card(grid, 0, "Мой голос", "ИСХОДЯЩИЙ ПЕРЕВОД",
                             "Русский → Испанский", "PTT / Непрерывно")
        self._direction_card(grid, 1, "Собеседник", "ВХОДЯЩИЙ ПЕРЕВОД",
                             "Испанский → Русский", "Захват звука игры / Discord")

        lower = tk.Frame(self.content, bg=BG)
        lower.pack(fill="both", expand=True)
        lower.columnconfigure((0, 1), weight=1, uniform="lower")
        bal = self.card(lower, "Звуковой баланс", "Настройка уровня синтезированного перевода")
        bal.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        self._slider_row(bal, "Перевод в наушники", "0–150%", 100)
        tk.Label(bal, text="Оригинальный звук регулируется в игре или Discord.",
                 bg=PANEL, fg=MUTED, font=("Segoe UI", 9), wraplength=390,
                 justify="left").pack(anchor="w", padx=20, pady=(2, 18))
        health = self.card(lower, "Компоненты", "Состояние после запуска движка")
        health.grid(row=0, column=1, sticky="nsew", padx=(7, 0))
        for name in ("ASR · Распознавание", "MT · Перевод", "TTS · Синтез"):
            r = tk.Frame(health, bg=PANEL)
            r.pack(fill="x", padx=20, pady=7)
            tk.Label(r, text=name, bg=PANEL, fg=TEXT, font=("Segoe UI", 9)).pack(side="left")
            tk.Label(r, text="● ОЖИДАНИЕ", bg=PANEL, fg=MUTED,
                     font=("Segoe UI", 8, "bold")).pack(side="right")
        tk.Label(health, text="Компоненты пока не подключены к Engine.",
                 bg=PANEL, fg="#71818F", font=("Segoe UI", 8)).pack(anchor="w", padx=20, pady=(8, 16))

    def _direction_card(self, parent, col, title, tag, route, mode):
        c = self.card(parent, title, tag, BLUE if col == 0 else GOLD)
        c.grid(row=0, column=col, sticky="nsew", padx=(0, 7) if col == 0 else (7, 0))
        tk.Label(c, text=route, bg=PANEL, fg=TEXT,
                 font=("Segoe UI Semibold", 15)).pack(anchor="w", padx=20, pady=(7, 3))
        tk.Label(c, text=mode, bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 9)).pack(anchor="w", padx=20)
        controls = tk.Frame(c, bg=PANEL)
        controls.pack(fill="x", padx=20, pady=(16, 18))
        self.button(controls, "Включить", lambda: self._notice("Для работы требуется подключение backend.")).pack(side="left")
        ttk.Combobox(controls, values=["es · Испанский", "en · Английский", "it · Итальянский"],
                     state="readonly", width=18).pack(side="right")

    def _slider_row(self, parent, label, unit, initial):
        row = tk.Frame(parent, bg=PANEL)
        row.pack(fill="x", padx=20, pady=(12, 6))
        tk.Label(row, text=label, bg=PANEL, fg=TEXT,
                 font=("Segoe UI", 9)).pack(side="left")
        value = tk.Label(row, text=f"{initial}%", bg=PANEL, fg=GOLD_HI,
                         font=("Segoe UI Semibold", 9))
        value.pack(side="right")
        scale = tk.Scale(parent, from_=0, to=150, orient="horizontal",
                         showvalue=False, bg=PANEL, fg=TEXT, troughcolor=PANEL_3,
                         activebackground=GOLD, highlightthickness=0,
                         command=lambda v: value.config(text=f"{int(float(v))}%"))
        scale.set(initial)
        scale.pack(fill="x", padx=18, pady=(0, 10))

    def _demo_start(self):
        self._notice("Это UI-макет. Реальный запуск Engine будет подключён OpenCode.")
    def _demo_stop(self):
        self._notice("Это UI-макет. Реальная остановка Engine будет подключена OpenCode.")
    def _notice(self, message):
        self.status = tk.Toplevel(self.root)
        self.status.title("RedZ Voice Studio")
        self.status.configure(bg=PANEL)
        self.status.resizable(False, False)
        tk.Label(self.status, text=message, bg=PANEL, fg=TEXT,
                 font=("Segoe UI", 10), padx=24, pady=20, wraplength=360).pack()
        self.button(self.status, "Закрыть", self.status.destroy, True).pack(pady=(0, 16))

    def _voices(self):
        self.section_heading("Голоса", "Запись, управление образцами и профилями синтеза")
        top = tk.Frame(self.content, bg=BG)
        top.pack(fill="x")
        sample = self.card(top, "Мой голос", "Локальный образец для клонирования")
        sample.pack(fill="x", pady=(0, 14))
        info = tk.Frame(sample, bg=PANEL)
        info.pack(fill="x", padx=20, pady=(5, 18))
        tk.Label(info, text="reference.wav", bg=PANEL, fg=TEXT,
                 font=("Segoe UI Semibold", 12)).pack(anchor="w")
        tk.Label(info, text="Статус образца будет получен из workspace после интеграции.",
                 bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", pady=(4, 12))
        for txt in ("Начать запись", "Остановить запись", "Прослушать образец", "Собрать образец из записей"):
            self.button(info, txt, lambda t=txt: self._notice(f"Действие «{t}» пока не подключено.")).pack(side="left", padx=(0, 7))
        profiles = self.card(self.content, "Профили входящего голоса",
                             "Выбор голоса для озвучивания перевода собеседника")
        profiles.pack(fill="x")
        row = tk.Frame(profiles, bg=PANEL)
        row.pack(fill="x", padx=20, pady=(5, 18))
        for name, desc in [("Natural", "Нейтральный"), ("Warm", "Мягкий"), ("Clear", "Чёткий")]:
            tile = tk.Frame(row, bg=PANEL_2, highlightbackground=BORDER, highlightthickness=1)
            tile.pack(side="left", fill="x", expand=True, padx=(0, 9), ipady=13)
            tk.Label(tile, text=name, bg=PANEL_2, fg=TEXT,
                     font=("Segoe UI Semibold", 11)).pack(pady=(5, 3))
            tk.Label(tile, text=desc, bg=PANEL_2, fg=MUTED,
                     font=("Segoe UI", 9)).pack()
            self.button(tile, "Выбрать", lambda n=name: self._notice(f"Профиль {n}: backend не подключён.")).pack(pady=10)

    def _settings(self):
        self.section_heading("Настройки", "Аудиоустройства, языки и управление поведением приложения")
        sections = [
            ("Аудиоустройства", [("Микрофон", ["Системное устройство по умолчанию"]),
                                 ("Вывод перевода", ["VB-CABLE Input", "Системное устройство по умолчанию"]),
                                 ("Захват собеседника", ["WASAPI Endpoint Loopback", "Legacy Input"])]),
            ("Языки", [("Язык исходящего перевода", ["Испанский", "Английский", "Итальянский"]),
                       ("Язык собеседника", ["Автоопределение", "Испанский", "Английский", "Итальянский"])]),
        ]
        for title, fields in sections:
            c = self.card(self.content, title)
            c.pack(fill="x", pady=(0, 13))
            for label, options in fields:
                row = tk.Frame(c, bg=PANEL)
                row.pack(fill="x", padx=20, pady=7)
                tk.Label(row, text=label, bg=PANEL, fg=TEXT,
                         font=("Segoe UI", 9)).pack(side="left")
                combo = ttk.Combobox(row, values=options, state="readonly", width=34)
                combo.current(0)
                combo.pack(side="right")
            tk.Frame(c, bg=PANEL, height=8).pack()
        c = self.card(self.content, "Горячие клавиши и диагностика")
        c.pack(fill="x")
        row = tk.Frame(c, bg=PANEL)
        row.pack(fill="x", padx=20, pady=(5, 18))
        tk.Label(row, text="PTT: назначение из текущих настроек  ·  Непрерывный режим: назначение из текущих настроек",
                 bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", pady=(0, 12))
        self.button(row, "Диагностика устройств", lambda: self._notice("Диагностика подключается к существующему Studio.")).pack(side="left")
        self.button(row, "Обновить устройства", lambda: self._notice("Обновление подключается к существующему Studio.")).pack(side="left", padx=8)

    def _history(self):
        self.section_heading("История переводов", "Последние исходящие и входящие фразы")
        c = self.card(self.content, "Последние события", "История будет загружаться из workspace/logs")
        c.pack(fill="both", expand=True)
        empty = tk.Frame(c, bg=PANEL)
        empty.pack(fill="both", expand=True, padx=20, pady=20)
        tk.Label(empty, text="История пока не подключена", bg=PANEL, fg=TEXT,
                 font=("Segoe UI Semibold", 15)).pack(pady=(65, 8))
        tk.Label(empty, text="После интеграции здесь появятся оригинал, перевод, направление и время.",
                 bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack()

if __name__ == "__main__":
    root = tk.Tk()
    app = RedZPrototype(root)
    root.mainloop()
